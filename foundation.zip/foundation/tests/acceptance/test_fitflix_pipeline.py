from pathlib import Path

from foundation.media.localmidiacanner import LocalMediaScanner

from foundation.parser.pipeline import ParserPipeline
from foundation.parser.filenameparser import FilenameParser
from foundation.parser.folder_parser import FolderParser
from foundation.parser.alias_parser import AliasParser


"""
Acceptance Test

Objetivo:
Validar a execução ponta a ponta da Foundation utilizando
a biblioteca real do Fitflix.

Fluxo esperado:

LocalMediaScanner
    ↓
ParserPipeline
    ↓
MetadataEnricher
    ↓
Matcher
    ↓
JsonExporter
    ↓
Manifest.json
"""



FITFLIX_MEDIA_PATH = (
    r"C:\Users\Matheus\Desktop\fitflix\media\exercicios"
)

scanner = LocalMediaScanner(
    Path(FITFLIX_MEDIA_PATH)
)

parser_pipeline = ParserPipeline([
    FilenameParser(),
    FolderParser(),
    AliasParser(),
])


